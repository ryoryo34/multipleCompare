# multipleCompare
Implement multiple compare with python.
